const express = require('express');
const {
    getBlogs,
    getBlogById,
    createBlog,
    updateBlog,
    deleteBlog,
} = require('../controllers/blogController');

const router = express.Router();

router.get('/', getBlogs);             // Get all blogs
router.get('/:id', getBlogById);       // Get a single blog by ID
router.post('/', createBlog);          // Create a new blog
router.put('/:id', updateBlog);        // Update a blog by ID
router.delete('/:id', deleteBlog);     // Delete a blog by ID

module.exports = router;
